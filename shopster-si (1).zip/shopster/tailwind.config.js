/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#FF5A00",
          hover: "#e04d00",
          light: "#fff3ee",
        },
        dark: "#1a1a2e",
      },
    },
  },
  plugins: [],
};
