# 🛒 Shopster.si – Slovenska E-commerce Platforma

Prototip spletne trgovine za slovenski trg, razvit z React, Tailwind CSS in Lucide React.

![Shopster Preview](https://img.shields.io/badge/React-18-blue?logo=react) ![Tailwind](https://img.shields.io/badge/Tailwind-CSS-38bdf8?logo=tailwindcss) ![Lucide](https://img.shields.io/badge/Lucide-React-orange)

## ✨ Funkcionalnosti

- **Header** – Logo, iskalna vrstica, ikone za prijavo, priljubljene in košarico
- **Hero Slider** – Avtomatski slider z akcijskimi baneri (3 diapozitivi)
- **Kategorije** – 10 kategorij z ikonami
- **Mreža izdelkov** – 9 produktnih kartic z ocenami, cenami in znački
- **Sidebar filtri** – Filtriranje po ceni, znamki, oceni in vrsti dostave
- **Košarica** – Stranski panel z dodajanjem/odstranjevanjem izdelkov
- **Lokalizacija** – Slovensko besedilo, EUR cene, slovenski ponudniki

## 🇸🇮 Slovensko lokalizirana vsebina

- Metode dostave: **Pošta Slovenije**, GLS, DPD
- Načini plačila: **Flik**, **Leanpay**, Visa, Mastercard
- Besedila: *Brezplačna dostava*, *Akcijska ponudba*, *Novo v ponudbi*
- Brezplačna dostava nad **50 €**

## 🚀 Zagon projekta

### Zahteve
- Node.js 16+
- npm ali yarn

### Namestitev

```bash
# Kloniraj repozitorij
git clone https://github.com/tvoje-ime/shopster-si.git
cd shopster-si

# Namesti odvisnosti
npm install

# Zaženi razvojni strežnik
npm start
```

Aplikacija se odpre na [http://localhost:3000](http://localhost:3000)

### Gradnja za produkcijo

```bash
npm run build
```

## 🗂️ Struktura projekta

```
shopster/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Header.jsx        # Navigacija, iskanje, ikone
│   │   ├── HeroSlider.jsx    # Avtomatski baner slider
│   │   ├── Categories.jsx    # Kategorije z ikonami
│   │   ├── ProductCard.jsx   # Kartica posameznega izdelka
│   │   ├── Sidebar.jsx       # Filtri (cena, znamka, ocena)
│   │   ├── CartModal.jsx     # Stranska košarica
│   │   └── TrustBar.jsx      # Dostava in plačilni znački
│   ├── context/
│   │   └── CartContext.js    # Globalno stanje košarice
│   ├── data/
│   │   └── products.js       # Podatki o izdelkih in kategorijah
│   ├── App.jsx               # Glavna komponenta
│   ├── index.js              # Vstopna točka
│   └── index.css             # Globalni slogi + Tailwind
├── tailwind.config.js
├── package.json
└── README.md
```

## 🎨 Dizajn

- **Primarna barva:** `#FF5A00` (oranžna – CTA gumbi, akcenti)
- **Temna barva:** `#1a1a2e` (navigacija, naslovi)
- **Ozadje:** `#f4f5f7` (svetlo siva)
- **Tipografija:** Segoe UI / system-ui

## 📦 Tehnologije

| Tehnologija | Različica | Opis |
|-------------|-----------|------|
| React | 18.x | UI framework |
| Tailwind CSS | 3.x | Utility-first CSS |
| Lucide React | 0.383 | Ikone |
| React Context | – | Upravljanje stanja košarice |

## 📄 Licenca

MIT – prosto za osebno in komercialno uporabo.
