import React, { useState } from "react";
import { CartProvider } from "./context/CartContext";
import Header from "./components/Header";
import HeroSlider from "./components/HeroSlider";
import Categories from "./components/Categories";
import Sidebar from "./components/Sidebar";
import ProductCard from "./components/ProductCard";
import CartModal from "./components/CartModal";
import TrustBar from "./components/TrustBar";
import { products } from "./data/products";

function ProductGrid({ filters }) {
  const [sort, setSort] = useState("popularity");

  const filtered = products.filter((p) => {
    if (filters.maxPrice && p.price > filters.maxPrice) return false;
    if (filters.brands && filters.brands.size > 0 && !filters.brands.has(p.brand)) return false;
    if (filters.minRating && p.rating < filters.minRating) return false;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sort === "price-asc") return a.price - b.price;
    if (sort === "price-desc") return b.price - a.price;
    if (sort === "rating") return b.rating - a.rating;
    return b.reviews - a.reviews;
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-base font-bold text-gray-800">
          Priporočeni Izdelki
          <span className="text-xs text-gray-400 font-normal ml-2">({sorted.length} izdelkov)</span>
        </h2>
        <select
          className="border border-gray-200 rounded-lg px-3 py-1.5 text-xs outline-none cursor-pointer"
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          <option value="popularity">Razvrsti: Priljubljenost</option>
          <option value="price-asc">Cena: od najnižje</option>
          <option value="price-desc">Cena: od najvišje</option>
          <option value="rating">Ocena</option>
        </select>
      </div>

      {sorted.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <div className="text-4xl mb-3">🔍</div>
          <p className="text-gray-400 text-sm">Noben izdelek ne ustreza filtrom.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {sorted.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [filters, setFilters] = useState({ maxPrice: 2000, brands: new Set(), minRating: 0 });

  return (
    <CartProvider>
      <div className="min-h-screen" style={{ backgroundColor: "#f4f5f7" }}>
        <Header />

        <main className="max-w-7xl mx-auto px-4 py-5 flex gap-5">
          <Sidebar onFilterChange={setFilters} />

          <div className="flex-1 min-w-0">
            <HeroSlider />
            <Categories />
            <ProductGrid filters={filters} />
            <TrustBar />
          </div>
        </main>

        <footer className="mt-10 py-6 text-center text-xs text-gray-400 border-t border-gray-200 bg-white">
          <p>© 2025 Shopster.si – Vaša slovenska spletna trgovina · Vse pravice pridržane</p>
          <p className="mt-1">
            <a href="#" className="hover:underline mx-2">Pogoji poslovanja</a>
            <a href="#" className="hover:underline mx-2">Zasebnost</a>
            <a href="#" className="hover:underline mx-2">Kontakt</a>
          </p>
        </footer>

        <CartModal />
      </div>
    </CartProvider>
  );
}
