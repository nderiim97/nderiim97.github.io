import React, { useState } from "react";
import { ShoppingCart, Heart, User, Search, Menu, X } from "lucide-react";
import { useCart } from "../context/CartContext";

export default function Header() {
  const { totalItems, setIsCartOpen } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: "Domov", href: "#" },
    { label: "📱 Elektronika", href: "#" },
    { label: "🏠 Dom & Vrt", href: "#" },
    { label: "👗 Moda", href: "#" },
    { label: "💄 Lepota", href: "#" },
    { label: "🚗 Avto", href: "#" },
    { label: "🎮 Igre", href: "#" },
    { label: "🔥 Akcija", href: "#", highlight: true },
  ];

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      {/* Top bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
        {/* Logo */}
        <a href="#" className="text-2xl font-extrabold tracking-tight whitespace-nowrap">
          <span style={{ color: "#FF5A00" }}>Shop</span>
          <span className="text-gray-900">ster</span>
          <span className="text-xs text-gray-400 font-normal">.si</span>
        </a>

        {/* Search */}
        <div
          className="flex-1 flex border-2 rounded-lg overflow-hidden"
          style={{ borderColor: "#FF5A00" }}
        >
          <input
            type="text"
            placeholder="Iskanje produktov, znamk in kategorij..."
            className="flex-1 px-4 py-2 text-sm outline-none bg-white"
          />
          <button
            className="px-5 py-2 text-white text-sm font-semibold flex items-center gap-2"
            style={{ backgroundColor: "#FF5A00" }}
          >
            <Search size={16} />
            Iskanje
          </button>
        </div>

        {/* Icons */}
        <div className="hidden md:flex items-center gap-4">
          <button className="flex flex-col items-center gap-0.5 text-gray-500 hover:text-orange-500 text-xs">
            <User size={22} />
            Prijava
          </button>
          <button className="flex flex-col items-center gap-0.5 text-gray-500 hover:text-orange-500 text-xs">
            <Heart size={22} />
            Priljubljeni
          </button>
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex flex-col items-center gap-0.5 text-gray-500 hover:text-orange-500 text-xs relative"
          >
            <ShoppingCart size={22} />
            Košarica
            {totalItems > 0 && (
              <span
                className="absolute -top-1 -right-1 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center font-bold"
                style={{ backgroundColor: "#FF5A00", fontSize: 10 }}
              >
                {totalItems}
              </span>
            )}
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-gray-600"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Nav */}
      <nav style={{ backgroundColor: "#1a1a2e" }}>
        <ul className="max-w-7xl mx-auto px-4 flex overflow-x-auto gap-0 scrollbar-hide">
          {navLinks.map((link) => (
            <li key={link.label}>
              <a
                href={link.href}
                className="block px-4 py-2.5 text-xs font-medium whitespace-nowrap transition-colors"
                style={{ color: link.highlight ? "#FF5A00" : "#ccc" }}
                onMouseEnter={(e) => (e.target.style.color = "#FF5A00")}
                onMouseLeave={(e) =>
                  (e.target.style.color = link.highlight ? "#FF5A00" : "#ccc")
                }
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 py-3 flex gap-6">
          <button className="flex items-center gap-2 text-sm text-gray-600">
            <User size={18} /> Prijava
          </button>
          <button className="flex items-center gap-2 text-sm text-gray-600">
            <Heart size={18} /> Priljubljeni
          </button>
          <button
            onClick={() => { setIsCartOpen(true); setMobileMenuOpen(false); }}
            className="flex items-center gap-2 text-sm text-gray-600 relative"
          >
            <ShoppingCart size={18} /> Košarica
            {totalItems > 0 && (
              <span
                className="text-white text-xs px-1.5 py-0.5 rounded-full font-bold"
                style={{ backgroundColor: "#FF5A00" }}
              >
                {totalItems}
              </span>
            )}
          </button>
        </div>
      )}
    </header>
  );
}
