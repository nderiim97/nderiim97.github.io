import React from "react";
import { ShoppingCart, Star } from "lucide-react";
import { useCart } from "../context/CartContext";

function StarRating({ rating }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={13}
          fill={i <= rating ? "#FF5A00" : "none"}
          stroke={i <= rating ? "#FF5A00" : "#d1d5db"}
        />
      ))}
    </div>
  );
}

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-200 cursor-pointer flex flex-col">
      {/* Image area */}
      <div className="bg-gray-50 h-36 flex items-center justify-center text-5xl relative">
        {product.badge && (
          <span
            className={`absolute top-2 left-2 text-white text-xs font-bold px-2 py-0.5 rounded`}
            style={{
              backgroundColor: product.badgeType === "new" ? "#00a86b" : "#FF5A00",
            }}
          >
            {product.badge}
          </span>
        )}
        {product.emoji}
      </div>

      {/* Info */}
      <div className="p-3 flex flex-col flex-1">
        <p className="text-xs text-gray-400 mb-0.5">{product.brand}</p>
        <p className="text-sm font-medium text-gray-800 mb-1.5 line-clamp-2 leading-snug">
          {product.name}
        </p>

        <div className="flex items-center gap-1.5 mb-2">
          <StarRating rating={product.rating} />
          <span className="text-xs text-gray-400">({product.reviews.toLocaleString()})</span>
        </div>

        <div className="flex items-baseline gap-2 mb-3 mt-auto">
          <span className="text-lg font-extrabold" style={{ color: "#FF5A00" }}>
            {product.price.toLocaleString()} €
          </span>
          {product.oldPrice && (
            <span className="text-xs text-gray-300 line-through">
              {product.oldPrice.toLocaleString()} €
            </span>
          )}
        </div>

        <button
          onClick={() => addToCart(product.id)}
          className="w-full text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 hover:opacity-90 active:scale-95 transition-all"
          style={{ backgroundColor: "#FF5A00" }}
        >
          <ShoppingCart size={14} />
          Dodaj v košarico
        </button>
      </div>
    </div>
  );
}
