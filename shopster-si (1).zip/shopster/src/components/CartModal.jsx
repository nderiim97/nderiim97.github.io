import React from "react";
import { X, Minus, Plus, Trash2, ShoppingCart } from "lucide-react";
import { useCart } from "../context/CartContext";

export default function CartModal() {
  const {
    cartItems,
    totalItems,
    totalPrice,
    freeDeliveryLeft,
    isCartOpen,
    setIsCartOpen,
    changeQty,
    removeItem,
  } = useCart();

  if (!isCartOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        onClick={() => setIsCartOpen(false)}
      />

      {/* Panel */}
      <div className="fixed top-0 right-0 h-full w-80 md:w-96 bg-white z-50 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <ShoppingCart size={20} style={{ color: "#FF5A00" }} />
            <h2 className="text-base font-bold">Moja košarica</h2>
            {totalItems > 0 && (
              <span
                className="text-white text-xs font-bold px-2 py-0.5 rounded-full"
                style={{ backgroundColor: "#FF5A00" }}
              >
                {totalItems}
              </span>
            )}
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={22} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-5 py-3">
          {cartItems.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-5xl mb-4">🛒</div>
              <p className="text-gray-400 text-sm">Vaša košarica je prazna</p>
              <button
                onClick={() => setIsCartOpen(false)}
                className="mt-4 text-sm font-semibold underline"
                style={{ color: "#FF5A00" }}
              >
                Nadaljuj z nakupovanjem
              </button>
            </div>
          ) : (
            cartItems.map((item) => (
              <div key={item.id} className="flex gap-3 items-start py-3 border-b border-gray-100">
                <div className="w-14 h-14 bg-gray-50 rounded-lg flex items-center justify-center text-3xl flex-shrink-0">
                  {item.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-gray-800 leading-tight line-clamp-2 mb-1">
                    {item.name}
                  </p>
                  <p className="text-sm font-extrabold" style={{ color: "#FF5A00" }}>
                    {(item.price * item.qty).toLocaleString()} €
                  </p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <button
                      onClick={() => changeQty(item.id, -1)}
                      className="w-6 h-6 border border-gray-200 rounded-md bg-gray-50 flex items-center justify-center hover:bg-gray-100"
                    >
                      <Minus size={12} />
                    </button>
                    <span className="text-sm font-semibold w-5 text-center">{item.qty}</span>
                    <button
                      onClick={() => changeQty(item.id, 1)}
                      className="w-6 h-6 border border-gray-200 rounded-md bg-gray-50 flex items-center justify-center hover:bg-gray-100"
                    >
                      <Plus size={12} />
                    </button>
                    <button
                      onClick={() => removeItem(item.id)}
                      className="ml-auto text-gray-300 hover:text-red-400 transition-colors"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {cartItems.length > 0 && (
          <div className="px-5 py-4 border-t border-gray-100">
            {freeDeliveryLeft > 0 ? (
              <div
                className="rounded-lg px-3 py-2 mb-3 text-xs"
                style={{ backgroundColor: "#fff8f4", border: "1px solid #ffe0cc", color: "#c45000" }}
              >
                🚚 Do brezplačne dostave manjka še{" "}
                <strong>{freeDeliveryLeft.toFixed(0)} €</strong>
              </div>
            ) : (
              <div
                className="rounded-lg px-3 py-2 mb-3 text-xs font-semibold"
                style={{ backgroundColor: "#f0faf5", border: "1px solid #c6f0dc", color: "#00a86b" }}
              >
                🎉 Brezplačna dostava zagotovljena!
              </div>
            )}

            <div className="flex justify-between text-base font-bold mb-3">
              <span>Skupaj:</span>
              <span>{totalPrice.toLocaleString()} €</span>
            </div>

            <button
              className="w-full text-white py-3.5 rounded-xl text-sm font-bold hover:opacity-90 active:scale-95 transition-all"
              style={{ backgroundColor: "#FF5A00" }}
            >
              Zaključi nakup →
            </button>

            <div className="flex justify-center gap-2 mt-3 flex-wrap">
              {["🟢 Flik", "🔵 Leanpay", "Visa", "Mastercard"].map((p) => (
                <span
                  key={p}
                  className="text-xs text-gray-400 bg-gray-50 border border-gray-200 px-2 py-0.5 rounded"
                >
                  {p}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
