import React, { useState } from "react";
import { brands } from "../data/products";

export default function Sidebar({ onFilterChange }) {
  const [maxPrice, setMaxPrice] = useState(1500);
  const [selectedBrands, setSelectedBrands] = useState(new Set(["Samsung", "Apple"]));
  const [minRating, setMinRating] = useState(0);
  const [freeDelivery, setFreeDelivery] = useState(false);

  const toggleBrand = (brand) => {
    const next = new Set(selectedBrands);
    next.has(brand) ? next.delete(brand) : next.add(brand);
    setSelectedBrands(next);
    onFilterChange?.({ maxPrice, brands: next, minRating, freeDelivery });
  };

  const handlePrice = (val) => {
    setMaxPrice(Number(val));
    onFilterChange?.({ maxPrice: Number(val), brands: selectedBrands, minRating, freeDelivery });
  };

  const SideCard = ({ title, children }) => (
    <div className="bg-white rounded-xl border border-gray-200 p-4 mb-4">
      <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-3">{title}</h3>
      {children}
    </div>
  );

  return (
    <aside className="w-52 flex-shrink-0 hidden md:block">
      <SideCard title="Cena (€)">
        <input
          type="range"
          min={0}
          max={2000}
          value={maxPrice}
          onChange={(e) => handlePrice(e.target.value)}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-400 mt-1">
          <span>0 €</span>
          <span className="font-semibold text-gray-700">{maxPrice.toLocaleString()} €</span>
        </div>
      </SideCard>

      <SideCard title="Znamka">
        {brands.map((b) => (
          <label key={b} className="flex items-center gap-2 mb-2 text-sm text-gray-600 cursor-pointer">
            <input
              type="checkbox"
              checked={selectedBrands.has(b)}
              onChange={() => toggleBrand(b)}
            />
            {b}
          </label>
        ))}
      </SideCard>

      <SideCard title="Minimalna ocena">
        {[5, 4, 3].map((r) => (
          <label key={r} className="flex items-center gap-2 mb-2 text-sm text-gray-600 cursor-pointer">
            <input
              type="checkbox"
              checked={minRating === r}
              onChange={() => {
                const next = minRating === r ? 0 : r;
                setMinRating(next);
                onFilterChange?.({ maxPrice, brands: selectedBrands, minRating: next, freeDelivery });
              }}
            />
            {"⭐".repeat(r)} ({r}+)
          </label>
        ))}
      </SideCard>

      <SideCard title="Dostava">
        <label className="flex items-center gap-2 mb-2 text-sm text-gray-600 cursor-pointer">
          <input
            type="checkbox"
            checked={freeDelivery}
            onChange={() => {
              const next = !freeDelivery;
              setFreeDelivery(next);
              onFilterChange?.({ maxPrice, brands: selectedBrands, minRating, freeDelivery: next });
            }}
          />
          Brezplačna dostava
        </label>
        <label className="flex items-center gap-2 mb-2 text-sm text-gray-600 cursor-pointer">
          <input type="checkbox" />
          Dostava danes
        </label>
        <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
          <input type="checkbox" />
          Prevzem v trgovini
        </label>
      </SideCard>
    </aside>
  );
}
