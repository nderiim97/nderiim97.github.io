import React from "react";
import { categories } from "../data/products";

export default function Categories() {
  return (
    <div className="flex gap-3 mb-5 overflow-x-auto pb-1 scrollbar-hide">
      {categories.map((cat) => (
        <button
          key={cat.label}
          className="flex flex-col items-center gap-1.5 cursor-pointer min-w-[68px] group"
        >
          <div
            className="w-14 h-14 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center text-2xl transition-all group-hover:scale-110"
            style={{ "--tw-border-opacity": 1 }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "#FF5A00";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "#e5e7eb";
            }}
          >
            {cat.emoji}
          </div>
          <span className="text-xs text-gray-500 font-medium text-center leading-tight">
            {cat.label}
          </span>
        </button>
      ))}
    </div>
  );
}
