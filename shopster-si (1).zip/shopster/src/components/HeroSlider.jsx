import React, { useState, useEffect } from "react";
import { heroSlides } from "../data/products";

export default function HeroSlider() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % heroSlides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const slide = heroSlides[current];

  return (
    <div
      className={`rounded-xl overflow-hidden bg-gradient-to-br ${slide.bg} relative h-48 md:h-56 flex items-center mb-5 transition-all duration-500`}
    >
      <div className="flex items-center w-full px-8 md:px-12 gap-6">
        <div className="flex-1">
          <span
            className="inline-block text-white text-xs font-bold px-3 py-1 rounded-full mb-3"
            style={{ backgroundColor: "#FF5A00" }}
          >
            {slide.badge}
          </span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white leading-tight mb-1">
            {slide.title}
          </h2>
          <p className="text-orange-400 font-bold text-lg mb-2">{slide.subtitle}</p>
          <p className="text-gray-400 text-sm mb-4">{slide.desc}</p>
          <button
            className="text-white font-bold px-6 py-2.5 rounded-lg text-sm transition-opacity hover:opacity-90"
            style={{ backgroundColor: "#FF5A00" }}
          >
            Kupi zdaj →
          </button>
        </div>
        <div className="text-7xl md:text-8xl opacity-90 select-none">{slide.emoji}</div>
      </div>

      {/* Dots */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
        {heroSlides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className="w-2 h-2 rounded-full transition-colors"
            style={{ backgroundColor: i === current ? "#FF5A00" : "rgba(255,255,255,0.3)" }}
          />
        ))}
      </div>
    </div>
  );
}
