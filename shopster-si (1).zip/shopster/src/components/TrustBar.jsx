import React from "react";
import { Truck, RotateCcw, Lock } from "lucide-react";

const deliveryProviders = ["📮 Pošta SLO", "GLS", "DPD"];
const paymentProviders = [
  { label: "Flik", bg: "#00a86b", color: "#fff" },
  { label: "Leanpay", bg: "#0066cc", color: "#fff" },
  { label: "Visa", bg: "#f0f2f5", color: "#333" },
  { label: "Mastercard", bg: "#f0f2f5", color: "#333" },
];

export default function TrustBar() {
  return (
    <div className="bg-white rounded-xl border border-gray-200 px-5 py-3 mt-5 flex flex-wrap gap-4 items-center">
      <div className="flex items-center gap-2 text-sm text-gray-600">
        <Truck size={18} style={{ color: "#FF5A00" }} />
        <span>
          <strong>Brezplačna dostava</strong> nad 50 €
        </span>
      </div>
      <div className="flex items-center gap-2 text-sm text-gray-600">
        <RotateCcw size={18} style={{ color: "#FF5A00" }} />
        <span>30 dni za vračilo</span>
      </div>
      <div className="flex items-center gap-2 text-sm text-gray-600">
        <Lock size={18} style={{ color: "#FF5A00" }} />
        <span>Varno plačilo</span>
      </div>

      <div className="ml-auto flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-gray-400">Dostava:</span>
          {deliveryProviders.map((d) => (
            <span
              key={d}
              className="text-xs font-semibold bg-gray-100 border border-gray-200 rounded px-2 py-0.5"
            >
              {d}
            </span>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-gray-400">Plačilo:</span>
          {paymentProviders.map((p) => (
            <span
              key={p.label}
              className="text-xs font-bold rounded px-2 py-0.5"
              style={{ backgroundColor: p.bg, color: p.color }}
            >
              {p.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
