import React, { createContext, useContext, useState } from "react";
import { products } from "../data/products";

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cart, setCart] = useState({});
  const [isCartOpen, setIsCartOpen] = useState(false);

  const addToCart = (id) => {
    setCart((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    setIsCartOpen(true);
  };

  const changeQty = (id, delta) => {
    setCart((prev) => {
      const next = { ...prev, [id]: Math.max(0, (prev[id] || 0) + delta) };
      if (next[id] === 0) delete next[id];
      return next;
    });
  };

  const removeItem = (id) => {
    setCart((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  };

  const cartItems = Object.entries(cart)
    .filter(([, qty]) => qty > 0)
    .map(([id, qty]) => ({
      ...products.find((p) => p.id === Number(id)),
      qty,
    }));

  const totalItems = cartItems.reduce((a, item) => a + item.qty, 0);
  const totalPrice = cartItems.reduce((a, item) => a + item.price * item.qty, 0);
  const freeDeliveryLeft = Math.max(0, 50 - totalPrice);

  return (
    <CartContext.Provider
      value={{
        cart,
        cartItems,
        totalItems,
        totalPrice,
        freeDeliveryLeft,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        changeQty,
        removeItem,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  return useContext(CartContext);
}
